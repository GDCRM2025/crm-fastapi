# backend/utils/data.py

COMUNAS = [
    'Algarrobo', 'Alhué', 'Buin', 'Cabildo', 'Calera de Tango', 'Calle Larga',
    'Cartagena', 'Casablanca', 'Catemu', 'Cerrillos', 'Cerro Navia', 'Chépica',
    'Chimbarongo', 'Codegua', 'Coinco', 'Colina', 'Coltauco', 'Conchalí',
    'Concón', 'Curacaví', 'Doñihue', 'El Bosque', 'El Monte', 'El Quisco',
    'El Tabo', 'Estación Central', 'Graneros', 'Hijuelas', 'Huechuraba',
    'Independencia', 'Isla de Maipo', 'La Calera', 'La Cisterna', 'La Cruz',
    'La Florida', 'La Granja', 'La Ligua', 'La Pintana', 'La Reina', 'Lampa',
    'Las Cabras', 'Las Condes', 'Limache', 'Llaillay', 'Lo Barnechea',
    'Lo Espejo', 'Lo Prado', 'Los Andes', 'Machalí', 'Macul', 'Maipú', 'Malloa',
    'María Pinto', 'Melipilla', 'Mostazal', 'Nancagua', 'Navidad', 'Ñuñoa',
    'Olivar', 'Olmué', 'Padre Hurtado', 'Paine', 'Palmilla', 'Panquehue',
    'Paredones', 'Pedro Aguirre Cerda', 'Peñaflor', 'Peñalolén', 'Peralillo',
    'Petorca', 'Peumo', 'Pichidegua', 'Pichilemu', 'Pirque', 'Placilla',
    'Providencia', 'Puchuncaví', 'Pudahuel', 'Puente Alto', 'Pumanque',
    'Putaendo', 'Quilicura', 'Quillota', 'Quilpué', 'Quinta de Tilcoco',
    'Quinta Normal', 'Rancagua', 'Recoleta', 'Renca', 'Rengo', 'Requínoa',
    'San Antonio', 'San Bernardo', 'San Felipe', 'San Fernando', 'San Joaquín',
    'San José de Maipo', 'San Miguel', 'San Pedro', 'San Ramón', 'San Vicente',
    'Santa Cruz', 'Santiago', 'Talagante', 'Tiltil', 'Valparaíso',
    'Villa Alemana', 'Viña del Mar', 'Vitacura', 'Zapallar', 'Batuco',
    'El Arrayán'
]
