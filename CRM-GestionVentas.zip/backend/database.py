# Importamos lo necesario para trabajar con PostgreSQL y SQLAlchemy
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Esta es la URL de conexión a tu base de datos PostgreSQL
# Formato: postgresql://usuario:contraseña@host/nombre_base_datos
DATABASE_URL = "postgresql://crmuser:crmpassword@localhost/crm"

# Creamos el motor (es el que abre la conexión a la base de datos)
engine = create_engine(DATABASE_URL)

# SessionLocal se usará para crear sesiones cada vez que hablemos con la base de datos
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base será la clase base para todos los modelos (tablas) que vamos a definir
Base = declarative_base()
