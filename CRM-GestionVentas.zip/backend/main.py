# backend/main.py
from fastapi import FastAPI, Request, Form, Response, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.status import HTTP_303_SEE_OTHER
from fastapi.staticfiles import StaticFiles
from passlib.context import CryptContext
from backend.database import Base, engine, SessionLocal
from backend.models import Usuario, RolEnum, CRMGeneral
from backend.utils.logger import registrar_log
from backend.utils.generador_codigo import generar_codigo_cliente
from backend.utils.helpers import obtener_fecha_actual, obtener_dia_mes_anio, obtener_segmentacion
from backend.utils.data import COMUNAS
import uuid
import time
import os

# === CONFIGURACION GENERAL ===
app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="backend/templates")
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
Base.metadata.create_all(bind=engine)

# === RUTA PRINCIPAL ===
@app.get("/", response_class=HTMLResponse)
async def inicio(request: Request):
    return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

# === FORMULARIO LOGIN ===
@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

# === PROCESAR LOGIN ===
@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request, response: Response, correo: str = Form(...), password: str = Form(...)):
    db = SessionLocal()
    try:
        usuario = db.query(Usuario).filter(Usuario.correo == correo).first()
        if not usuario or not pwd_context.verify(password, usuario.contraseña):
            return templates.TemplateResponse("login.html", {"request": request, "error": "Correo o contraseña incorrectos"})

        registrar_log("Inicio de sesión", usuario.id_usuario)
        response = RedirectResponse(url="/panel", status_code=HTTP_303_SEE_OTHER)
        response.set_cookie("user_id", usuario.id_usuario, httponly=True)
        response.set_cookie("last_active", str(int(time.time())), httponly=True)
        return response
    except Exception as e:
        return templates.TemplateResponse("login.html", {"request": request, "error": f"Error interno: {str(e)}"})
    finally:
        db.close()

# === PANEL USUARIO ===
@app.get("/panel", response_class=HTMLResponse)
async def panel(request: Request, user_id: str = Cookie(None), last_active: str = Cookie(None)):
    if not user_id:
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    tiempo_actual = int(time.time())
    if last_active and (tiempo_actual - int(last_active)) > 3600:
        resp = RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)
        resp.delete_cookie("user_id")
        resp.delete_cookie("last_active")
        registrar_log("Sesión cerrada por inactividad", user_id)
        return resp

    db = SessionLocal()
    try:
        usuario = db.query(Usuario).filter(Usuario.id_usuario == user_id).first()
        registrar_log("Ingreso al panel", user_id)
        response = templates.TemplateResponse("panel.html", {
            "request": request,
            "usuario": usuario  # pasamos el usuario completo para construir el menú según su rol
        })
        response.set_cookie("last_active", str(int(time.time())), httponly=True)
        return response
    finally:
        db.close()

# === FORMULARIO NUEVO LEAD ===
@app.get("/crear_lead", response_class=HTMLResponse)
async def crear_lead_form(request: Request, user_id: str = Cookie(None)):
    db = SessionLocal()
    try:
        usuario = db.query(Usuario).filter(Usuario.id_usuario == user_id).first()
        codigo = generar_codigo_cliente(usuario.marcas, usuario.nombre_usuario)
        marcas = usuario.marcas.split(",") if usuario.rol == RolEnum.EjecVen else ["CAMALEON", "EXPRESS", "DEL SABOR", "GOURMET"]

        return templates.TemplateResponse("crear_lead.html", {
            "request": request,
            "codigo_cliente": codigo,
            "comunas": COMUNAS,
            "marcas_disponibles": marcas
        })
    finally:
        db.close()

# === GUARDAR LEAD ===
@app.post("/crear_lead", response_class=HTMLResponse)
async def guardar_lead(
    request: Request,
    codigo_cliente: str = Form(...),
    nombre: str = Form(...),
    comuna: str = Form(...),
    telefono: str = Form(...),
    email: str = Form(...),
    tipo_cliente: str = Form(...),
    plataforma: str = Form(...),
    fecha_evento: str = Form(...),
    marca: str = Form(...),
    user_id: str = Cookie(None)
):
    db = SessionLocal()
    try:
        usuario = db.query(Usuario).filter(Usuario.id_usuario == user_id).first()
        fecha_ingreso = obtener_fecha_actual()
        dia, mes, año = obtener_dia_mes_anio(fecha_evento)
        link_ws = f"https://wa.me/56{telefono}?text=Hola {nombre}, soy de eventos {marca.upper()}! 😄"
        estado = "Nuevo"
        seguimiento = "Pendiente"
        segmentacion = obtener_segmentacion(0)

        nuevo = CRMGeneral(
            codigo_cliente=codigo_cliente,
            fecha_ingreso=fecha_ingreso,
            marca=marca,
            nombre_cliente=nombre,
            categoria_cliente="Por Definir",
            tipo_cliente=tipo_cliente,
            plataforma=plataforma,
            fecha_evento=fecha_evento,
            dia=dia,
            mes=mes,
            semana="",
            año=año,
            comuna=comuna if comuna else "Por Confirmar",
            telefono=telefono,
            link_whatsapp=link_ws,
            email=email,
            monto_cotizado="0",
            estado=estado,
            fecha_cierre="",
            seguimiento=seguimiento,
            fecha_seguimiento="",
            creado_por=usuario.nombre_usuario,
            nro_cotizacion="",
            segmentacion=segmentacion
        )

        db.add(nuevo)
        db.commit()
        registrar_log("Lead creado", usuario.id_usuario)
        return RedirectResponse(url="/panel", status_code=HTTP_303_SEE_OTHER)
    finally:
        db.close()

# === FORMULARIO CREAR USUARIO ===
@app.get("/crear_usuario", response_class=HTMLResponse)
async def crear_usuario_form(request: Request):
    return templates.TemplateResponse("register_user.html", {"request": request})

# === PROCESAR CREACION USUARIO ===
@app.post("/crear_usuario")
async def crear_usuario_post(
    request: Request,
    nombre: str = Form(...),
    correo: str = Form(...),
    password: str = Form(...),
    rol: RolEnum = Form(...),
    marcas: str = Form(None),
):
    db = SessionLocal()
    try:
        id_usuario = f"{rol}-{''.join(nombre.upper().split())[:8]}-{str(uuid.uuid4())[:4]}"
        hash_pwd = pwd_context.hash(password)

        nuevo = Usuario(
            id_usuario=id_usuario,
            nombre_usuario=nombre.upper(),
            correo=correo,
            contraseña=hash_pwd,
            rol=rol,
            status="Activo",
            marcas=marcas if rol == RolEnum.EjecVen else None
        )

        db.add(nuevo)
        db.commit()
        registrar_log(f"Usuario creado: {correo}", id_usuario)
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    except Exception as e:
        return HTMLResponse(content=f"<h3>Error: {e}</h3>")
    finally:
        db.close()

# === RECUPERAR CONTRASEÑA ===
@app.get("/recuperar_contrasena", response_class=HTMLResponse)
async def recuperar_contrasena(request: Request):
    return templates.TemplateResponse("recuperar_contrasena.html", {"request": request})
